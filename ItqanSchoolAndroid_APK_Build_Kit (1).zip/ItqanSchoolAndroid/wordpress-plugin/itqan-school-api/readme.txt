=== Itqan School API ===
Contributors: itqanschool
Tags: school, android, api, education
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.1.0

REST API for Itqan School Android app. Admins can create student accounts; students and parents share one Student ID/password account.

== Update / Installation ==
1. Back up WordPress first.
2. Deactivate the previous Itqan School API plugin.
3. Replace its plugin folder with this version (or upload this ZIP if WordPress permits replacing the existing plugin).
4. Activate the plugin. Existing API health and notices endpoints remain compatible.
5. Ensure HTTPS is active.

== Student workflow ==
An administrator logs into the app using an existing WordPress administrator username/password. In Admin > শিক্ষার্থী যুক্ত করুন, enter name, class and guardian phone (roll optional). The API generates an ID like ITS-2026-0001 and a temporary password if one is not supplied. Give the Student ID and temporary password to the family. Student and parent use the same account. Change the password after first login.

== Endpoints ==
GET /wp-json/itqan/v1/health (public)
GET /wp-json/itqan/v1/notices (public published notices)
POST /wp-json/itqan/v1/login {"student_id":"ITS-2026-0001","password":"..."} (also accepts username for staff/admin)
POST /wp-json/itqan/v1/logout (Bearer)
GET /wp-json/itqan/v1/me (Bearer)
GET /wp-json/itqan/v1/dashboard (Bearer)
GET /wp-json/itqan/v1/students (administrator only)
POST /wp-json/itqan/v1/students (administrator only; create student)
PUT /wp-json/itqan/v1/students/{user_id} (administrator only)
POST /wp-json/itqan/v1/students/{user_id}/reset-password (administrator only)
GET /wp-json/itqan/v1/timetable|results|attendance|homework|fees (Bearer; student ownership filter)

== Create student example ==
POST /wp-json/itqan/v1/students
Authorization: Bearer ADMIN_TOKEN
Content-Type: application/json
{"name":"শিক্ষার্থীর নাম","class":"Class 1","roll":"12","guardian_name":"অভিভাবকের নাম","guardian_phone":"01XXXXXXXXX"}

== Security ==
- Only WordPress users with manage_options can create/list/update student accounts.
- Student login is the Student ID and password; parent shares this same account.
- API requires HTTPS for login and limits repeated failed login attempts per IP.
- Passwords are stored by WordPress password hashing; generated temporary password is returned only once in the create/reset response.
- Do not share administrator credentials or temporary passwords in public. Use a unique admin account and keep WordPress/plugins updated.
- Before production use, test with dummy records, configure backups, privacy notice/consent and review hosting security. Student data is sensitive.
