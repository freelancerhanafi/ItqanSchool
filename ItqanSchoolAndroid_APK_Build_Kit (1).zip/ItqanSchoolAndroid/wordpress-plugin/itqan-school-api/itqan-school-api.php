<?php
/**
 * Plugin Name: Itqan School API
 * Description: Student provisioning and secure REST API for Itqan School Android app.
 * Version: 1.1.0
 * Author: Itqan International School
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) { exit; }

final class Itqan_School_API {
    const NS = 'itqan/v1';
    const TOKEN_PREFIX = 'itqan_api_token_';
    const TOKEN_TTL = 43200;
    const VERSION = '1.1.0';

    public static function init() {
        register_activation_hook(__FILE__, [__CLASS__, 'activate']);
        add_action('init', [__CLASS__, 'register_content_types']);
        add_action('rest_api_init', [__CLASS__, 'register_routes']);
    }

    public static function activate() {
        add_role('itqan_student', 'Itqan Student', ['read' => true]);
        add_role('itqan_teacher', 'Itqan Teacher', ['read' => true]);
        self::register_content_types();
        flush_rewrite_rules();
    }

    public static function register_content_types() {
        $types = [
            'itqan_notice' => ['Notice', 'Notices', true],
            'itqan_timetable' => ['Timetable', 'Timetables', false],
            'itqan_result' => ['Result', 'Results', false],
            'itqan_attendance' => ['Attendance', 'Attendance', false],
            'itqan_homework' => ['Homework', 'Homework', false],
            'itqan_fee' => ['Fee Record', 'Fee Records', false],
        ];
        foreach ($types as $type => $labels) {
            register_post_type($type, [
                'labels' => ['name' => __($labels[1], 'itqan-school-api'), 'singular_name' => __($labels[0], 'itqan-school-api')],
                'public' => $labels[2], 'show_ui' => true, 'show_in_rest' => true, 'rest_base' => $type,
                'supports' => ['title', 'editor', 'author', 'custom-fields'],
                'capability_type' => 'post', 'map_meta_cap' => true,
                'menu_icon' => 'dashicons-welcome-learn-more',
            ]);
        }
    }

    public static function register_routes() {
        register_rest_route(self::NS, '/health', ['methods'=>'GET','callback'=>[__CLASS__,'health'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS, '/login', ['methods'=>'POST','callback'=>[__CLASS__,'login'],'permission_callback'=>'__return_true']);
        register_rest_route(self::NS, '/logout', ['methods'=>'POST','callback'=>[__CLASS__,'logout'],'permission_callback'=>[__CLASS__,'require_user']]);
        register_rest_route(self::NS, '/me', ['methods'=>'GET','callback'=>[__CLASS__,'me'],'permission_callback'=>[__CLASS__,'require_user']]);
        register_rest_route(self::NS, '/dashboard', ['methods'=>'GET','callback'=>[__CLASS__,'dashboard'],'permission_callback'=>[__CLASS__,'require_user']]);
        register_rest_route(self::NS, '/notices', ['methods'=>'GET','callback'=>[__CLASS__,'notices'],'permission_callback'=>'__return_true']);
        foreach (['timetable','results','attendance','homework','fees'] as $resource) {
            register_rest_route(self::NS, '/'.$resource, ['methods'=>'GET','callback'=>function($request) use ($resource){ return self::list_records($request,$resource); },'permission_callback'=>[__CLASS__,'require_user']]);
        }
        register_rest_route(self::NS, '/students', [
            ['methods'=>'GET','callback'=>[__CLASS__,'students'],'permission_callback'=>[__CLASS__,'require_admin']],
            ['methods'=>'POST','callback'=>[__CLASS__,'create_student'],'permission_callback'=>[__CLASS__,'require_admin']],
        ]);
        register_rest_route(self::NS, '/students/(?P<id>\d+)', ['methods'=>'PUT','callback'=>[__CLASS__,'update_student'],'permission_callback'=>[__CLASS__,'require_admin']]);
        register_rest_route(self::NS, '/students/(?P<id>\d+)/reset-password', ['methods'=>'POST','callback'=>[__CLASS__,'reset_student_password'],'permission_callback'=>[__CLASS__,'require_admin']]);
    }

    public static function health() { return ['ok'=>true,'name'=>'Itqan School API','version'=>self::VERSION,'time'=>current_time('c')]; }

    private static function bearer_token() {
        $header = isset($_SERVER['HTTP_AUTHORIZATION']) ? trim($_SERVER['HTTP_AUTHORIZATION']) : '';
        if (!$header && function_exists('getallheaders')) { $headers=getallheaders(); $header=isset($headers['Authorization'])?trim($headers['Authorization']):''; }
        return preg_match('/Bearer\s+(.+)/i',$header,$m) ? trim($m[1]) : '';
    }
    private static function current_api_user() {
        $token=self::bearer_token(); if(!$token) return false;
        $id=get_transient(self::TOKEN_PREFIX.hash('sha256',$token));
        if(!$id) return false;
        $user=get_user_by('id',(int)$id);
        if(!$user || get_user_meta($user->ID,'itqan_account_status',true)==='inactive') return false;
        return $user;
    }
    public static function require_user() {
        $user=self::current_api_user();
        if(!$user) return new WP_Error('itqan_unauthorized','অনুগ্রহ করে সঠিক আইডি ও পাসওয়ার্ড দিয়ে আবার লগইন করুন।',['status'=>401]);
        wp_set_current_user($user->ID); return true;
    }
    public static function require_admin() {
        $auth=self::require_user(); if(is_wp_error($auth)) return $auth;
        if(!current_user_can('manage_options')) return new WP_Error('itqan_forbidden','শুধু অ্যাডমিন এই কাজটি করতে পারবেন।',['status'=>403]);
        return true;
    }
    public static function require_admin_or_teacher() {
        $auth=self::require_user(); if(is_wp_error($auth)) return $auth;
        $u=wp_get_current_user();
        if(!current_user_can('manage_options') && !in_array('itqan_teacher',(array)$u->roles,true)) return new WP_Error('itqan_forbidden','অনুমতি নেই।',['status'=>403]);
        return true;
    }

    public static function login($request) {
        if(!is_ssl()) return new WP_Error('itqan_https_required','নিরাপদ লগইনের জন্য HTTPS আবশ্যক।',['status'=>400]);
        $ip=isset($_SERVER['REMOTE_ADDR'])?sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])):'unknown';
        $rate_key='itqan_login_attempts_'.hash('sha256',$ip);
        $attempts=(int)get_transient($rate_key);
        if($attempts>=10) return new WP_Error('itqan_rate_limited','অনেকবার ভুল চেষ্টা হয়েছে। ১৫ মিনিট পর আবার চেষ্টা করুন।',['status'=>429]);
        $login=sanitize_user((string)($request->get_param('student_id') ?: $request->get_param('username')));
        $password=(string)$request->get_param('password');
        if(!$login || !$password) return new WP_Error('itqan_login_fields','আইডি ও পাসওয়ার্ড দিন।',['status'=>400]);
        $user=wp_authenticate($login,$password);
        if(is_wp_error($user)) { set_transient($rate_key,$attempts+1,15*MINUTE_IN_SECONDS); return new WP_Error('itqan_login_failed','আইডি অথবা পাসওয়ার্ড সঠিক নয়।',['status'=>401]); }
        if(get_user_meta($user->ID,'itqan_account_status',true)==='inactive') return new WP_Error('itqan_account_inactive','এই অ্যাকাউন্টটি বর্তমানে বন্ধ আছে। স্কুল অফিসে যোগাযোগ করুন।',['status'=>403]);
        delete_transient($rate_key);
        $token=bin2hex(random_bytes(32));
        set_transient(self::TOKEN_PREFIX.hash('sha256',$token),$user->ID,self::TOKEN_TTL);
        return new WP_REST_Response(['token'=>$token,'expires_in'=>self::TOKEN_TTL,'user'=>self::public_user($user)],200);
    }
    public static function logout() { $t=self::bearer_token(); if($t) delete_transient(self::TOKEN_PREFIX.hash('sha256',$t)); return ['ok'=>true,'message'=>'লগআউট হয়েছে']; }

    private static function public_user($user) {
        $roles=(array)$user->roles; $role='student';
        if(in_array('administrator',$roles,true)) $role='admin';
        elseif(in_array('itqan_teacher',$roles,true)||in_array('teacher',$roles,true)) $role='teacher';
        elseif(in_array('itqan_student',$roles,true)) $role='student';
        $data=['id'=>(int)$user->ID,'name'=>$user->display_name,'username'=>$user->user_login,'role'=>$role];
        if($role==='student') {
            $data['student_id']=get_user_meta($user->ID,'itqan_student_code',true) ?: $user->user_login;
            $data['class']=get_user_meta($user->ID,'itqan_class',true);
            $data['roll']=get_user_meta($user->ID,'itqan_roll',true);
            $data['guardian_name']=get_user_meta($user->ID,'itqan_guardian_name',true);
            $data['guardian_phone']=get_user_meta($user->ID,'itqan_guardian_phone',true);
        }
        return $data;
    }
    public static function me() { return ['user'=>self::public_user(self::current_api_user())]; }
    public static function dashboard() {
        $u=self::current_api_user();
        return ['user'=>self::public_user($u),'notices'=>self::query_posts('itqan_notice',5,true),'features'=>['রুটিন','ফলাফল','উপস্থিতি','হোমওয়ার্ক','ফি তথ্য']];
    }
    private static function query_posts($type,$limit,$published=false) {
        $posts=get_posts(['post_type'=>$type,'posts_per_page'=>$limit,'orderby'=>'date','order'=>'DESC','post_status'=>$published?'publish':['publish','private']]);
        return array_map(function($p){return ['id'=>(int)$p->ID,'title'=>get_the_title($p),'content'=>wp_strip_all_tags(apply_filters('the_content',$p->post_content)),'date'=>get_post_time('c',true,$p)];},$posts);
    }
    public static function notices($request) { $limit=min(50,max(1,(int)$request->get_param('per_page')?:20)); return ['items'=>self::query_posts('itqan_notice',$limit,true)]; }

    private static function allowed_student_user_ids($user) {
        if(in_array('itqan_student',(array)$user->roles,true)) return [(int)$user->ID];
        return [];
    }
    public static function list_records($request,$resource) {
        $map=['timetable'=>'itqan_timetable','results'=>'itqan_result','attendance'=>'itqan_attendance','homework'=>'itqan_homework','fees'=>'itqan_fee'];
        $type=$map[$resource]; $user=self::current_api_user(); $staff=current_user_can('manage_options')||in_array('itqan_teacher',(array)$user->roles,true);
        $args=['post_type'=>$type,'posts_per_page'=>min(100,max(1,(int)$request->get_param('per_page')?:50)),'post_status'=>$staff?['publish','private']:['publish'],'orderby'=>'date','order'=>'DESC'];
        $requested=absint($request->get_param('student_id'));
        if(!$staff) {
            $ids=self::allowed_student_user_ids($user);
            if(!$ids) return ['items'=>[]];
            if($requested && !in_array($requested,$ids,true)) return new WP_Error('itqan_forbidden','এই শিক্ষার্থীর তথ্য দেখার অনুমতি নেই।',['status'=>403]);
            $args['meta_query']=[['key'=>'itqan_student_id','value'=>$requested?:$ids,'compare'=>$requested?'=':'IN']];
        } elseif($requested) $args['meta_query']=[['key'=>'itqan_student_id','value'=>$requested,'compare'=>'=']];
        $posts=get_posts($args);
        return ['items'=>array_map(function($p){return ['id'=>(int)$p->ID,'title'=>get_the_title($p),'content'=>wp_strip_all_tags(apply_filters('the_content',$p->post_content)),'date'=>get_post_time('c',true,$p),'student_id'=>(int)get_post_meta($p->ID,'itqan_student_id',true)];},$posts)];
    }

    private static function student_item($user) {
        return ['id'=>(int)$user->ID,'student_id'=>get_user_meta($user->ID,'itqan_student_code',true)?:$user->user_login,'name'=>$user->display_name,'class'=>get_user_meta($user->ID,'itqan_class',true),'roll'=>get_user_meta($user->ID,'itqan_roll',true),'guardian_name'=>get_user_meta($user->ID,'itqan_guardian_name',true),'guardian_phone'=>get_user_meta($user->ID,'itqan_guardian_phone',true),'status'=>get_user_meta($user->ID,'itqan_account_status',true)?:'active'];
    }
    public static function students($request) {
        $users=get_users(['role'=>'itqan_student','number'=>500,'orderby'=>'registered','order'=>'DESC']);
        return ['items'=>array_map([__CLASS__,'student_item'],$users)];
    }
    public static function create_student($request) {
        $name=sanitize_text_field((string)$request->get_param('name'));
        $class=sanitize_text_field((string)$request->get_param('class'));
        $roll=sanitize_text_field((string)$request->get_param('roll'));
        $guardian_phone=preg_replace('/[^0-9+]/','',(string)$request->get_param('guardian_phone'));
        if(!$name||!$class||!$guardian_phone) return new WP_Error('itqan_missing_fields','শিক্ষার্থীর নাম, শ্রেণি ও অভিভাবকের মোবাইল নম্বর আবশ্যক।',['status'=>400]);
        $code=sanitize_user((string)$request->get_param('student_id'));
        if(!$code) {
            $year=wp_date('Y'); $last=(int)get_option('itqan_student_sequence_'.$year,0)+1;
            do { $code='ITS-'.$year.'-'.str_pad((string)$last,4,'0',STR_PAD_LEFT); $last++; } while(username_exists($code));
            update_option('itqan_student_sequence_'.$year,$last-1,false);
        }
        if(username_exists($code)) return new WP_Error('itqan_student_id_exists','এই Student ID আগে থেকেই ব্যবহৃত হয়েছে।',['status'=>409]);
        $email=sanitize_email((string)$request->get_param('email'));
        if(!$email) $email=strtolower($code).'@students.itqan.invalid';
        if(email_exists($email)) return new WP_Error('itqan_email_exists','এই ইমেইলটি আগে থেকেই ব্যবহৃত হয়েছে।',['status'=>409]);
        $password=(string)$request->get_param('password'); $generated=false;
        if(!$password) { $password=wp_generate_password(12,false,false); $generated=true; }
        if(strlen($password)<8) return new WP_Error('itqan_weak_password','পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে।',['status'=>400]);
        $user_id=wp_insert_user(['user_login'=>$code,'user_pass'=>$password,'user_email'=>$email,'display_name'=>$name,'nickname'=>$name,'role'=>'itqan_student']);
        if(is_wp_error($user_id)) return $user_id;
        update_user_meta($user_id,'itqan_student_code',$code);
        update_user_meta($user_id,'itqan_class',$class);
        update_user_meta($user_id,'itqan_roll',$roll);
        update_user_meta($user_id,'itqan_guardian_name',sanitize_text_field((string)$request->get_param('guardian_name')));
        update_user_meta($user_id,'itqan_guardian_phone',$guardian_phone);
        update_user_meta($user_id,'itqan_account_status','active');
        update_user_meta($user_id,'itqan_created_by',get_current_user_id());
        $user=get_user_by('id',$user_id);
        $response=['ok'=>true,'message'=>'শিক্ষার্থীর অ্যাকাউন্ট তৈরি হয়েছে।','student'=>self::student_item($user),'temporary_password'=>$password,'password_generated'=>$generated];
        return new WP_REST_Response($response,201);
    }
    public static function update_student($request) {
        $id=absint($request['id']); $user=get_user_by('id',$id);
        if(!$user || !in_array('itqan_student',(array)$user->roles,true)) return new WP_Error('itqan_student_not_found','শিক্ষার্থী পাওয়া যায়নি।',['status'=>404]);
        $fields=['name'=>'display_name','class'=>'itqan_class','roll'=>'itqan_roll','guardian_name'=>'itqan_guardian_name','guardian_phone'=>'itqan_guardian_phone','status'=>'itqan_account_status'];
        foreach($fields as $input=>$meta) if($request->get_param($input)!==null) {
            $value=sanitize_text_field((string)$request->get_param($input));
            if($input==='name') wp_update_user(['ID'=>$id,'display_name'=>$value,'nickname'=>$value]);
            else { if($input==='status' && !in_array($value,['active','inactive'],true)) return new WP_Error('itqan_bad_status','status active অথবা inactive হতে হবে।',['status'=>400]); update_user_meta($id,$meta,$value); }
        }
        return ['ok'=>true,'student'=>self::student_item(get_user_by('id',$id))];
    }
    public static function reset_student_password($request) {
        $id=absint($request['id']); $user=get_user_by('id',$id);
        if(!$user || !in_array('itqan_student',(array)$user->roles,true)) return new WP_Error('itqan_student_not_found','শিক্ষার্থী পাওয়া যায়নি।',['status'=>404]);
        $password=(string)$request->get_param('password'); if(!$password) $password=wp_generate_password(12,false,false);
        if(strlen($password)<8) return new WP_Error('itqan_weak_password','পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে।',['status'=>400]);
        wp_set_password($password,$id);
        return ['ok'=>true,'message'=>'পাসওয়ার্ড পরিবর্তন হয়েছে।','temporary_password'=>$password];
    }
}
Itqan_School_API::init();
