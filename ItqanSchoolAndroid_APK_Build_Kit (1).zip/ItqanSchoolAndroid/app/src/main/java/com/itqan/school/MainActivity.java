package com.itqan.school;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.graphics.Color;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w=getWindow();
        w.setStatusBarColor(Color.rgb(16,60,53));
        w.setNavigationBarColor(Color.rgb(16,60,53));
        web=new WebView(this);
        web.setBackgroundColor(Color.rgb(244,247,245));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        try {
            InputStream in=getAssets().open("index.html");
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            byte[] buffer=new byte[8192]; int n;
            while((n=in.read(buffer))!=-1) out.write(buffer,0,n);
            String page=new String(out.toByteArray(), StandardCharsets.UTF_8);
            web.loadDataWithBaseURL("https://itqanschool.com/", page, "text/html", "UTF-8", null);
        } catch(Exception e) {
            web.loadData("<h3>অ্যাপ লোড করা যায়নি।</h3>","text/html","UTF-8");
        }
    }
    @Override public void onBackPressed() { if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
